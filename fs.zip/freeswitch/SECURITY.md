# Security Policy

## Reporting a Vulnerability

Send an e-mail to security@signalwire.com to report a vulnerability. If accepted, we'll create a security advisory and add you and your team as collaborators. Please allow our team sufficient time to resolve the vulnerability before disclosing it; we'll remain in contact about the fix and may ask for your assistance to verify it is resolved.
