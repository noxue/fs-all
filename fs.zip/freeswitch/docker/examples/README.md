##### Dockerfile examples showing how to build FreeSWITCH without installing FreeSWITCH repo.

[Debian 11](https://github.com/signalwire/freeswitch/blob/dockerfile/docker/examples/Debian11/Dockerfile "Debian 11")

